
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 08/07/2016 17:01:47
-- Generated from EDMX file: C:\Users\SY Phath\Downloads\HeterProjet\HeterProjet\EmbaucheModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [EmbaucheBD2];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Personnel]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Personnel];
GO
IF OBJECT_ID(N'[dbo].[Fonction]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Fonction];
GO
IF OBJECT_ID(N'[dbo].[DemandPoste]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DemandPoste];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Personnel'
CREATE TABLE [dbo].[Personnel] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nom] nvarchar(max)  NOT NULL,
    [Prenom] nvarchar(max)  NOT NULL,
    [FctCode] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Fonction'
CREATE TABLE [dbo].[Fonction] (
    [Code] nvarchar(max)  NOT NULL,
    [Label] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'DemandPoste'
CREATE TABLE [dbo].[DemandPoste] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Intitule] nvarchar(max)  NOT NULL,
    [Description] nvarchar(max)  NOT NULL,
    [DateCreation] nvarchar(max)  NULL,
    [Metier] nvarchar(max)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'Personnel'
ALTER TABLE [dbo].[Personnel]
ADD CONSTRAINT [PK_Personnel]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Code] in table 'Fonction'
ALTER TABLE [dbo].[Fonction]
ADD CONSTRAINT [PK_Fonction]
    PRIMARY KEY CLUSTERED ([Code] ASC);
GO

-- Creating primary key on [Id] in table 'DemandPoste'
ALTER TABLE [dbo].[DemandPoste]
ADD CONSTRAINT [PK_DemandPoste]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------
