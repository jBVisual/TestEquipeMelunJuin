﻿
using System;
using System.Data.SqlClient;

namespace HeterProjet
{
    partial class DemandePosteView
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTitrePoste = new System.Windows.Forms.Label();
            this.tbTitrePoste = new System.Windows.Forms.TextBox();
            this.cbMetier = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rtbDescription = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonValider = new System.Windows.Forms.Button();
            this.buttonAnnuler = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelTitrePoste
            // 
            this.labelTitrePoste.AutoSize = true;
            this.labelTitrePoste.Location = new System.Drawing.Point(52, 48);
            this.labelTitrePoste.Name = "labelTitrePoste";
            this.labelTitrePoste.Size = new System.Drawing.Size(85, 17);
            this.labelTitrePoste.TabIndex = 0;
            this.labelTitrePoste.Text = "Titre Poste :";
            // 
            // tbTitrePoste
            // 
            this.tbTitrePoste.Location = new System.Drawing.Point(167, 48);
            this.tbTitrePoste.Name = "tbTitrePoste";
            this.tbTitrePoste.Size = new System.Drawing.Size(165, 22);
            this.tbTitrePoste.TabIndex = 1;
            // 
            // cbMetier
            // 
            this.cbMetier.FormattingEnabled = true;
            this.cbMetier.Items.AddRange(new object[] {
            "Metier1",
            "Metier2",
            "Metier3"});
            this.cbMetier.Location = new System.Drawing.Point(167, 103);
            this.cbMetier.Name = "cbMetier";
            this.cbMetier.Size = new System.Drawing.Size(165, 24);
            this.cbMetier.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Metier :";
            // 
            // rtbDescription
            // 
            this.rtbDescription.Location = new System.Drawing.Point(167, 178);
            this.rtbDescription.Name = "rtbDescription";
            this.rtbDescription.Size = new System.Drawing.Size(268, 137);
            this.rtbDescription.TabIndex = 5;
            this.rtbDescription.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 178);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Description :";
            // 
            // buttonValider
            // 
            this.buttonValider.Location = new System.Drawing.Point(199, 344);
            this.buttonValider.Name = "buttonValider";
            this.buttonValider.Size = new System.Drawing.Size(75, 23);
            this.buttonValider.TabIndex = 7;
            this.buttonValider.Text = "Valider";
            this.buttonValider.UseVisualStyleBackColor = true;
            this.buttonValider.Click += new System.EventHandler(this.buttonValider_Click);
            // 
            // buttonAnnuler
            // 
            this.buttonAnnuler.Location = new System.Drawing.Point(351, 344);
            this.buttonAnnuler.Name = "buttonAnnuler";
            this.buttonAnnuler.Size = new System.Drawing.Size(75, 23);
            this.buttonAnnuler.TabIndex = 8;
            this.buttonAnnuler.Text = "Annuler";
            this.buttonAnnuler.UseVisualStyleBackColor = true;
            this.buttonAnnuler.Click += new System.EventHandler(this.buttonAnnuler_Click);
            // 
            // DemandePosteView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 413);
            this.Controls.Add(this.buttonAnnuler);
            this.Controls.Add(this.buttonValider);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rtbDescription);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbMetier);
            this.Controls.Add(this.tbTitrePoste);
            this.Controls.Add(this.labelTitrePoste);
            this.Name = "DemandePosteView";
            this.Text = "Demande Poste";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void buttonValider_Click(object sender, EventArgs e)
        {
            //On crée "d" une instance de la table DemandPoste
            DemandPoste d = new DemandPoste();
            //On ajoute à d les données issues de la fenetre
            d.Intitule = this.tbTitrePoste.Text;
            d.Metier = this.cbMetier.Text;
            d.Description = this.rtbDescription.Text;
            DateTime dt = DateTime.Now;
            d.DateCreation = dt.ToString();
            
            //On crée un container pour mettre à jour la table DemandPoste de la BD
            EmbaucheModelContainer em = new EmbaucheModelContainer();
            em.DemandPoste.Add(d);
            //on sauvegarde les nouvelles données inscrites dans la base
            em.SaveChanges();
        }

        
        
        private System.Windows.Forms.Label labelTitrePoste;
        private System.Windows.Forms.TextBox tbTitrePoste;
        private System.Windows.Forms.ComboBox cbMetier;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox rtbDescription;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonValider;
        private System.Windows.Forms.Button buttonAnnuler;
    }
}

#endregion